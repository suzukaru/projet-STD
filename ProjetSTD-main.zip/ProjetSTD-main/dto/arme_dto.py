from dataclasses import dataclass

@dataclass
class ArmeDTO:
    id: int
    name: str
    color: str